package com.example.demo.bootstrap;

import com.example.demo.domain.InhousePart;
import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;

    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        // Check if parts and products repositories are empty
        if ((partRepository.count() == 0) && (productRepository.count() == 0)) {

            // Create In house part object for parts and products
            InhousePart computerCase = new InhousePart();
            InhousePart powerSupply = new InhousePart();
            InhousePart motherBoard = new InhousePart();
            InhousePart powerStrip = new InhousePart();
            InhousePart desktopProcessor = new InhousePart();

            //create the computer case values and save
            computerCase.setName("Computer CaseWith USB 3.0 Mini Tower");
            computerCase.setInv(15);
            computerCase.setMinInv(1);
            computerCase.setMaxInv(20);
            computerCase.setPrice(147.99);
            computerCase.setPartId(1);
            partRepository.save(computerCase);

            //create the computer power supply values
            powerSupply.setName("Power Supply");
            powerSupply.setInv(10);
            powerSupply.setMinInv(1);
            powerSupply.setMaxInv(15);
            powerSupply.setPrice(9.99);
            powerSupply.setPartId(2);
            partRepository.save(powerSupply);

            //create the computer motherboard values
            motherBoard.setName("Motherboard");
            motherBoard.setInv(15);
            motherBoard.setMinInv(1);
            motherBoard.setMaxInv(20);
            motherBoard.setPrice(108.99);
            motherBoard.setPartId(3);
            partRepository.save(motherBoard);


            //create the computer surge protector power strip
            powerStrip.setName("Surge Protector Power Strip");
            powerStrip.setInv(20);
            powerStrip.setMinInv(1);
            powerStrip.setMaxInv(25);
            powerStrip.setPrice(14.99);
            powerStrip.setPartId(4);
            partRepository.save(powerStrip);

            //create the computer surge protector power strip
            desktopProcessor.setName("AMD Ryzen 5 7600X - Zen 4 6-Core 4.7 (Desktop Processor)");
            desktopProcessor.setInv(15);
            desktopProcessor.setMinInv(1);
            desktopProcessor.setMaxInv(20);
            desktopProcessor.setPrice(224.99);
            desktopProcessor.setPartId(5);
            partRepository.save(desktopProcessor);

            // Create products
            Product standardPC = new Product(6, "Standard Home PC System", 499.99, 15);
            Product gamingComputer = new Product(7, "PC Gaming System", 987.99, 10);
            Product preOwnedPc = new Product(8, "Ultimate PC Gaming System(Second-Hand)", 899.99, 20);
            Product workComputer = new Product(9, "Work PC System", 888.99, 25);
            Product ultimateComputer = new Product(10 , "Ultimate Pc Gaming System",999.99, 12);

            // Save products to repository
            productRepository.save(standardPC);
            productRepository.save(gamingComputer);
            productRepository.save(preOwnedPc);
            productRepository.save(workComputer);
            productRepository.save(ultimateComputer);
        }

        //print name of a part and the company of an outsourced part
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            System.out.println(part.getName()+" "+part.getCompanyName());
        }


        System.out.println("Started in Bootstrap");
        System.out.println("Number of Products"+productRepository.count());
        System.out.println(productRepository.findAll());
        System.out.println("Number of Parts"+partRepository.count());
        System.out.println(partRepository.findAll());

    }
}
